/** Automatically generated file. DO NOT MODIFY */
package org.jfedor.nxtremotecontrol;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}